﻿namespace WindowsFormsApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBox = new System.Windows.Forms.PictureBox();
            this.loc_richTextBox = new System.Windows.Forms.RichTextBox();
            this.register_button = new System.Windows.Forms.Button();
            this.del_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.SuspendLayout();
            // 
            // picBox
            // 
            this.picBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picBox.BackColor = System.Drawing.SystemColors.Control;
            this.picBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBox.Location = new System.Drawing.Point(71, 73);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(605, 308);
            this.picBox.TabIndex = 0;
            this.picBox.TabStop = false;
            // 
            // loc_richTextBox
            // 
            this.loc_richTextBox.Location = new System.Drawing.Point(695, 12);
            this.loc_richTextBox.Name = "loc_richTextBox";
            this.loc_richTextBox.Size = new System.Drawing.Size(164, 81);
            this.loc_richTextBox.TabIndex = 1;
            this.loc_richTextBox.Text = "";
            // 
            // register_button
            // 
            this.register_button.Location = new System.Drawing.Point(478, 419);
            this.register_button.Name = "register_button";
            this.register_button.Size = new System.Drawing.Size(75, 23);
            this.register_button.TabIndex = 2;
            this.register_button.Text = "追加";
            this.register_button.UseVisualStyleBackColor = true;
            this.register_button.Click += new System.EventHandler(this.register_button_Click);
            // 
            // del_button
            // 
            this.del_button.Location = new System.Drawing.Point(601, 419);
            this.del_button.Name = "del_button";
            this.del_button.Size = new System.Drawing.Size(75, 23);
            this.del_button.TabIndex = 3;
            this.del_button.Text = "削除";
            this.del_button.UseVisualStyleBackColor = true;
            this.del_button.Click += new System.EventHandler(this.del_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 525);
            this.Controls.Add(this.del_button);
            this.Controls.Add(this.register_button);
            this.Controls.Add(this.loc_richTextBox);
            this.Controls.Add(this.picBox);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picBox;
        private System.Windows.Forms.RichTextBox loc_richTextBox;
        private System.Windows.Forms.Button register_button;
        private System.Windows.Forms.Button del_button;
    }
}

