﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        int startx = 0;
        int starty = 0;
        int imgx = 0;
        int imgy = 0;
        float zoom = 1;
        bool mousepressed = false;

        Point mouseDown;
        PointF selLoc = new PointF(0, 0);
        List<PointF> markerLoc = new List<PointF>();

        Image markerImg = Image.FromFile(@"D:\selvaraj\marker.png");

        public Form1()
        {
            InitializeComponent();
            picBox.MouseDown += new MouseEventHandler(imageBox_MouseDown);
            picBox.MouseUp += new MouseEventHandler(imageBox_MouseUp);
            picBox.MouseMove += new MouseEventHandler(pictureBox_MouseMove);
            imageBox_Paint();
        }

        private void pictureBox_MouseMove(object sender, EventArgs e)
        {
            MouseEventArgs mouse = e as MouseEventArgs;

            if (mouse.Button == MouseButtons.Left)
            {
                Point mousePosNow = mouse.Location;

                int deltaX = mousePosNow.X - mouseDown.X;
                int deltaY = mousePosNow.Y - mouseDown.Y;

                imgx = (int)(startx + (deltaX / zoom));
                imgy = (int)(starty + (deltaY / zoom));
                imageBox_Paint();
            }
        }

        private void imageBox_MouseDown(object sender, EventArgs e)
        {
            MouseEventArgs mouse = e as MouseEventArgs;

            if (mouse.Button == MouseButtons.Left)
            {
                if (!mousepressed)
                {
                    mousepressed = true;
                    mouseDown = mouse.Location;
                    startx = imgx;
                    starty = imgy;
                }
            }
            else if (mouse.Button == MouseButtons.Right)
            {
                setLocation(mouse.X, mouse.Y);
                loc_richTextBox.Text += "X : " + selLoc.X + ", Y : " + selLoc.Y + Environment.NewLine;
                loc_richTextBox.SelectionStart = loc_richTextBox.Text.Length;
                loc_richTextBox.ScrollToCaret();
                markerLoc.Add(new PointF(selLoc.X, selLoc.Y));
                drawMarker();
            }
        }

        private void imageBox_MouseUp(object sender, EventArgs e)
        {
            mousepressed = false;
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            float oldzoom = zoom;
            if (e.Delta > 0)
            {
                zoom += 1F;
            }
            else if (e.Delta < 0)
            {
                zoom = Math.Max(zoom - 1F, 1F);
            }
            MouseEventArgs mouse = e as MouseEventArgs;
            Point mousePosNow = mouse.Location;

            int x = mousePosNow.X - picBox.Location.X;
            int y = mousePosNow.Y - picBox.Location.Y;

            int oldimagex = (int)(x / oldzoom);
            int oldimagey = (int)(y / oldzoom);

            int newimagex = (int)(x / zoom);
            int newimagey = (int)(y / zoom);

            imgx = newimagex - oldimagex + imgx;
            imgy = newimagey - oldimagey + imgy;

            imageBox_Paint();  // calls imageBox_Paint
        }

        private void imageBox_Paint()
        {
            Image img = Image.FromFile(@"D:\selvaraj\img.jpg");
            Bitmap canvas = new Bitmap(picBox.Width, picBox.Height);
            Graphics g = Graphics.FromImage(canvas);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.ScaleTransform(zoom, zoom);
            g.DrawImage(img, imgx, imgy);
            img.Dispose();
            g.Dispose();
            picBox.Image = canvas;
            drawMarker();
        }

        private void setLocation(int X, int Y)
        {
            selLoc.X = (X / zoom) - imgx;
            selLoc.Y = (Y / zoom) - imgy;
        }

        private void drawMarker()
        {
            Bitmap bmp = new Bitmap(picBox.Image);
            Graphics g = Graphics.FromImage(bmp);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.ScaleTransform(zoom, zoom);
            markerLoc = markerLoc.Distinct().ToList();
            for (int i = 0; i < markerLoc.Count; i++)
            {
                PointF temp = new PointF(0, 0);
                temp.X = markerLoc[i].X + imgx;
                temp.Y = markerLoc[i].Y + imgy;
                g.DrawImage(markerImg, temp.X - (markerImg.Width / 2), temp.Y - markerImg.Height, markerImg.Width, markerImg.Height);
            }
            g.Dispose();
            picBox.Image = bmp;
        }

        private void register_button_Click(object sender, EventArgs e)
        {
            loc_richTextBox.Text = loc_richTextBox.Text.Trim();
            for (int i = 0; i < loc_richTextBox.Lines.Count(); i++)
            {
                string[] tempLoc = loc_richTextBox.Lines[i].Replace("X : ", "").Replace("Y : ", "").Split(',');
                markerLoc.Add(new PointF(float.Parse(tempLoc[0]), float.Parse(tempLoc[1])));
            }
            imageBox_Paint();
        }

        private void del_button_Click(object sender, EventArgs e)
        {
            loc_richTextBox.Text = loc_richTextBox.Text.Trim();
            for (int i = 0; i < loc_richTextBox.Lines.Count(); i++)
            {
                string[] tempLoc = loc_richTextBox.Lines[i].Replace("X : ", "").Replace("Y : ", "").Split(',');
                markerLoc.Remove(new PointF(float.Parse(tempLoc[0]), float.Parse(tempLoc[1])));
            }
            imageBox_Paint();
        }
    }
}
